<?php

session_save_path("../session"); 
session_start();
include 'connect.php';

if(empty($_POST['checkin'])  		||
   empty($_POST['checkout']) 		||
   empty($_POST['hotelname']) 		||
   empty($_POST['email'])	||
   !filter_var($_POST['email'],FILTER_VALIDATE_EMAIL))
   {
	   
	   
	   
	   
	echo "No arguments Provided!";
	return false;

//  To redirect form on a particular page



   }
$checkout = $_POST['checkout'];
$email_address = $_POST['email'];
$checkin = $_POST['checkin'];
$hotelname = $_POST['hotelname'];
$rooms = $_POST['rooms'];
$currentdate = $_POST['currentdate'];
$name = $_POST['name'];

$sql = "INSERT INTO booking (hotel_name,username,date_in,date_out,number_room,booking_date)
VALUES ('$hotelname','$name','$checkin','$checkout','$rooms','$currentdate')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
	
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);



	
	
// Create the email and send the message

$email_subject = "Your reservation confirmation";
$email_body = "Thank you for using BGHotels to arrange your holiday! We hope you will have an amazing adventure.\n\n"."Here are the details of your booking:\n\nHotel: $hotelname\n\nEmail: $email_address\n\nCheck in date: $checkin\n\nCheckout date:$checkout\n\nIf you have registered with us you will be able to see this information in your profile. Please contact us via our contact form in case of any inquiries.\n\n Disclaimer: This email is generated from a fictional site designed for a University Major Project. If you got this email by accident please do ignore it.\n\n Kind Regards, \n\n BGHotels";
$headers = "From: noreply@bulgarianhotels.com\n"; // This is the email address the generated message will be from. We recommend using something like noreply@yourdomain.com.
$headers .= "Reply-To: $email_address";	
mail($email_address,$email_subject,$email_body,$headers);

return true;	




?>