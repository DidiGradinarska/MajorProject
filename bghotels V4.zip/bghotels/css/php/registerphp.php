	<?php
// Stesting if the username exists if not a registration can be created
	
				if(isset($_POST['submit']))  
				{
					$username = $_POST['username'];
						$username = $_POST['username'];
				$name = $_POST['name'];
				$email = $_POST['email'];
				$phone = $_POST['phone'];
					
					$sql = "SELECT * FROM user WHERE username = '".$username."'";
					$result = mysqli_query($conn, $sql);
					
					if (mysqli_num_rows($result) > 0) {
						$sql = "SELECT password FROM user WHERE username = '".$username."'";
						$result = mysqli_query($conn, $sql);
						while($row = mysqli_fetch_assoc($result)) {
							
							
							
							echo'Username is taken';
						}
					}
					
					else                
				{
					$pass= password_hash($_POST['password'], PASSWORD_BCRYPT); //http://php.net/manual/en/function.password-hash.php Using the PASSWORD_BCRYPT as the algorithm, will result in the password parameter being truncated to a maximum length of 72 characters. Need to limit password length
				if (!$pass){ die ("Something went wrong!");
				}
				else{
				$sql = "INSERT INTO user (Username,Name,Password,Email,Phone) VALUES ('$username','$name','$pass','$email','$phone')"; 
				mysqli_query($conn,$sql);}
				mysqli_close($conn);
				echo 'You have registered successfully!';
				header( 'refresh:1.5;url=index' ) ;
				} 
					
				}
				else                
				{
					echo '';
				} 
				

?>		