<?php
ob_start();
session_start();
if(!isset($_SESSION['username']))
	{
							header( 'Location: index' ) ;
							exit();
	}
else
	{
						
$nameuser = $_SESSION['username'];



	//include 'php/registerphp.php';
	include 'php/connect.php';
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Bulgarian Hotels</title>

    <!-- Bootstrap Core CSS - Uses Bootswatch Flatly Theme: http://bootswatch.com/flatly/ -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/freelancer.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<link rel="icon" 
      type="image/png" 
      href="img/logo.gif"> 
</head>

<body id="page-top" class="index">

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index">Bulgarian Hotels</a>
            </div>
			 <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
				<li class="page-scroll">
                        <a href="#bookings">Your Bookings</a>
                    </li>
					<li class="page-scroll">
                        <a href="#youreviews">Your Reviews</a>
                    </li>
					<li class="page-scroll">
                        <a href="hotel">Hotels</a>
                    </li>
					<li class="page-scroll">
                        <a href="feedback">Reviews</a>
                    </li>
                   
				
					
					
					
							<li class="page-scroll">
								<a href="logout">Logout</a>
							</li>
						
                </ul>
            </div>
            <!-- /.navbar-collapse -->
			   </div>
        <!-- /.container-fluid -->
    </nav>
	 <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
				<br>
                    <h2>Welcome </h2><br><b><h4><?php echo $_SESSION['username'] ?></h4></b>
                    <hr class="star-primary">
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
                    <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
                    <form action="" method="post" >	<?php 
							$sql = "SELECT * FROM `user` WHERE username='$nameuser' ";
							$result = mysqli_query($conn, $sql);
							
							if (mysqli_num_rows($result) > 0) {
								// output data of each row
								while($row = mysqli_fetch_assoc($result)) {
								
								?>
						
                     
						 <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>New Name</label>
                                <input type="text" maxlength="100" class="form-control" value="<?php echo "{$row['name']}";?>"  id="name" name="name" required data-validation-required-message="Please enter your username.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
						
						
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>New Email Address</label>
                                <input type="email" maxlength="100" class="form-control" value="<?php echo "{$row['email']}";?>" id="email" name="email" required data-validation-required-message="Please enter your email address.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <div class="row control-group">
                            <div class="form-group col-xs-12 floating-label-form-group controls">
                                <label>New Phone Number</label>
                                <input type="tel" maxlength="20" class="form-control" pattern="^(?:\(\d{3}\)|\d{4})[- ]?\d{3}[- ]?\d{4}$" value="<?php echo "{$row['phone']}";?>" id="phone" name="phone" placeholder="Phone Number (07871171359)" required data-validation-required-message="Please enter your phone number like 07871171359.">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        
                        <br>
                        <div id="success"></div>
                        <div class="row">
                            <div class="form-group col-xs-12">
                                <input type="submit" name="submit" value="Update" class="btn btn-success btn-lg">
                            </div>
                        </div>
                    </form>
					<?php
					}
							} else {
								echo "";
									}
						
// updating the user's record


					if(isset($_POST['submit']))  
					{
						$name = $_POST['name'];
						$email = $_POST['email'];
						$phone = $_POST['phone'];
						
						$sql = "UPDATE user SET name='$name', email='$email', phone='$phone' WHERE username='$nameuser'";

						if (mysqli_query($conn, $sql)) {
							echo '<div class="alert alert-success">
							  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							  <strong>Success!</strong> Information updated successfully!
							</div>';
						} else {
							echo ' <div class="alert alert-danger">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Caution!</strong>  Something went wrong :
					</div>' . mysqli_error($conn);
						}

						//mysqli_close($conn);
						
					}	
						
						else {echo'';}
					?>

					
                </div>
            </div>
        </div>
    </section>
	 <!-- prety Grid Section -->
	    <section class="success" id="about">
        <div class="container">
            
           
        </div>
    </section>
    <section id="bookings">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Bookings</h2>
                    <hr class="star-primary">
                </div>
            </div>
            <div class="row">
               
									   
																	<?php
																				
																		$sql = "SELECT * FROM booking WHERE hotel_name='$nameuser'";
																		$result = mysqli_query($conn, $sql);
																		?>		<table class="table table-striped">
																					<thead>
																					  <tr>
																						<th>Booking ID</th>
																						<th>User email</th>
																						<th>Hotel Name</th>
																						<th>Check in date</th>
																						<th>Check out date</th>
																						<th>Nuber of rooms</th>
																						<th>Booking date</th>
																					  </tr>
																					</thead>
																					<?php
																			if (mysqli_num_rows($result) > 0) 
																				{
																				// output data of each row
																					while($row = mysqli_fetch_assoc($result)) {
																						$do=$row['date_out'];
																		//echo "<tbody>";
																		echo	'<form method="get" action="feedback">	';
																					echo "<tr>";
																						echo "<td>" .  $row["booking_id"]  . "</td>\n";
																						echo "<td>" .  $row["address_email"]  . "</td>\n";
																						echo "<td>" .  $row["hotel_name"]  . "</td>\n";
																					    echo "<td>" .  $row["date_in"]  . "</td>\n";
																						 echo "<td>" .  $row["date_out"]  . "</td>\n";
																						  echo "<td>" .  $row["number_room"]  . "</td>\n";
																						   echo "<td>" .  $row["booking_date"]  . "</td>\n";
																						   
																					echo "</tr>";								?>
														
																				</form>
																			
																			 
																			<?php		
																			
																				
																			}
																			//echo "</tbody>";
																			echo "</table>";
																				} 
																			else 
																			{
																				echo "</table>";
																			echo ' <div class="alert alert-warning">
																			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
																			<strong>Sorry!</strong> You currently do not have any bookings!
																		  </div>';
																			}
			
																		
																		?> 
																										
               

            </div>
        </div>
    </section>
	 <!-- prety Grid Section -->
	    <section class="success" id="about">
        <div class="container">
            
           
        </div>
    </section>
	 <!-- reviews Grid Section -->
    <section id="youreviews">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Your Reviews</h2>
                    <hr class="star-primary">
                </div>
            </div>
			
            <div class="row">
		<div class="col-lg-8 col-lg-offset-2">			
		<?php
																				
																		$sql = "SELECT * FROM feedback WHERE hotel_name='$nameuser' ";
																		$result = mysqli_query($conn, $sql);
																		?>		<table class="table table-striped">
																					<thead>
																					  <tr>
																						<th>Username</th>
																						<th>Hotel Name</th>
																						<th>Review</th>
																						<th>Review Date</th>
																					  </tr>
																					</thead>
																					<?php
																			if (mysqli_num_rows($result) > 0) 
																				{
																				// output data of each row
																					while($row = mysqli_fetch_assoc($result)) {
																		//echo "<tbody>";
																		echo	'<form method="post" action="php/deleterev">	';
																					echo "<tr>";
																						
																						echo "<td>" .  $row["username"]  . "</td>\n";
																						echo "<td>" .  $row["hotel_name"]  . "</td>\n";
																					    echo "<td>" .  $row["feedback"]  . "</td>\n";
																						 echo "<td>" .  $row["date"]  . "</td>\n";
																					
																					echo "</tr>";								?>
														
																				</form>
																			
																			 
																			<?php		
																			
																				
																			}
																			//echo "</tbody>";
																			echo "</table>";
																				} 
																			else 
																			{
																				echo "</table>";
																			echo '<div class="alert alert-warning">
																			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
																			<strong>Sorry!</strong> You currently do not have any reviews!
																		  </div>';
																			}
			
																		mysqli_close($conn);
																		?> 
												
			   
			   
			   
		</div>	   
            </div>
        </div>
    </section>

  <?php include "core/footer.php";?>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-top page-scroll visible-xs visible-sm">
        <a class="btn btn-primary" href="#page-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </div>


    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/freelancer.js"></script>

</body>

</html>
<?php

	}
?>