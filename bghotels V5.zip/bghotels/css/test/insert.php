<html>

<body>

 <form action="insert.php" method="post">
 Username : <input type="text" name="username"><br/>
 Name : <input type="text" name="name"><br/>

  Password : <input type="text" name="password"><br/>
   Email : <input type="text" name="email"><br/>
    Phone : <input type="text" name="phone"><br/>
	
 
 <input type="submit" name="submit">
 </form>

 

<?php
if (isset($_POST['submit'])){ //check if submit button has been pressed the code will only run it it is pressed
$con = mysql_connect("localhost","didi","980500");
if (!$con){
die("Can not connect: " . mysql_error());
}
mysql_select_db("bghotels",$con);

$sql = "INSERT INTO user (Username,Name,Password,Email,Phone) VALUES ('$_POST[username]','$_POST[name]','$_POST[password]','$_POST[email]','$_POST[phone]')";

mysql_query($sql,$con);

mysql_close($con);
}
?>

</body>

</html>