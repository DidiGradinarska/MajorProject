<?php

session_save_path("/session");

	session_start();
error_reporting( error_reporting() & ~E_NOTICE )
?>