

<?php
$servername = "localhost";
$username = "didi";
$password2 = "980500";
$dbname = "bghotels";

// Create connection
$conn = mysqli_connect($servername, $username, $password2, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$pass= password_hash($_POST['password'], PASSWORD_BCRYPT); //Using the PASSWORD_BCRYPT as the algorithm, will result in the password parameter being truncated to a maximum length of 72 characters. 
if (!$pass){ die ("Something went wrong!");
}
else{
$sql = "INSERT INTO user (Username,Name,Password,Email,Phone) VALUES ('$_POST[username]','$_POST[name]','$pass','$_POST[email]','$_POST[phone]')";
mysqli_query($conn,$sql);}
mysqli_close($conn);

?>