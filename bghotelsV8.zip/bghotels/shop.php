<?php 

session_start();
include 'php/connect.php';
//$hotel_name = $_POST['hotel_name'];

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Bulgarian Hotels</title>

    <!-- Bootstrap Core CSS - Uses Bootswatch Flatly Theme: http://bootswatch.com/flatly/ -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/freelancer.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Bulgarian Hotels</title>

    <!-- Bootstrap Core CSS - Uses Bootswatch Flatly Theme: http://bootswatch.com/flatly/ -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/freelancer.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<link rel="icon" 
      type="image/png" 
      href="http://users.aber.ac.uk/dtg1/cs25010/images/logo.gif"> 


</head>

<body id="page-top" class="index">
	<?php //echo $interest_name; ?>
    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index">Bulgarian Hotels</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
					<li class="page-scroll">
                        <a href="#interests">Shops</a>
                    </li>
					 <li class="page-scroll">
                        <a href="hotel">Hotels</a>
                    </li>
					<li class="page-scroll">
                        <a href="feedback">Reviews</a>
                    </li>
				
					
					
				<?php
						if(!isset($_SESSION['username']))
						{
							?><li class="page-scroll">
								<a href="login">Log In</a>
							</li>
							 <li class="page-scroll">
								<a href="register">Register</a>
							</li>
							<?php
						}
						else
						{
							?>
							<li class="page-scroll">
								<a href="profile"><?php echo $_SESSION['username'] ?></a>
							</li>
							<li class="page-scroll">
								<a href="logout">Logout</a>
							</li>
							<?php
						}
					?>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <!-- Header -->
    <header>
        <div class="container" >
            <div class="row">
                <div class="col-lg-12">
                    <img class="img-responsive" src="img/profile.png" alt="">
                    <div class="intro-text">
						
                        <span class="name">Shops</span>
                        <hr class="star-light">
                        <span class="skills">These are some amazing shops showing what the bulgarian culture has to offer. Please select a location explore!</span>
                    </div>
                </div>
            </div>
        </div>
    </header>

  

   
	

 <section id="interests">

        <div class="container">

            <div class="row">

                <div class="col-lg-12 text-center">

                    <h2>Shops</h2>

                    <hr class="star-primary">

                </div>

            </div>

			<div class="row" align="center">  

<a href="#filtercontainer" class="btn btn-primary" data-toggle="collapse">Filter Options</a>	

 <div   id="filtercontainer" class="collapse" >   <br>		

			<?php

					

					echo "<form name='filter' method='post' action='shop'>";	
				$sql = "SELECT DISTINCT location_name FROM shop"; // this changes in different filters depending what i want 
				$result = mysqli_query($conn, $sql);

				echo "<label for='location_name'>Location: </label>";
					echo "<select class='form-control input-sm' name='selectFilter[]'>";// i need to give any filter this name copy from here
					echo "<option value=''></option>";
					while ($row = mysqli_fetch_assoc($result)) {
						echo "<option value='" . $row['location_name'] . "'>" . $row['location_name'] . "</option>";
					}
					echo "</select>"; //to here to create new filter
				
					
					echo "<br/> <input class='btn btn-primary' name='filterSubmit' type='submit'>";
				echo"</form>";

			?>

           </div> </div><br><br>

            <div class="row">

					<?php

					

						if(isset($_POST['interest_name'])) {
							$sql = "SELECT * FROM location WHERE interest_name = '".$interest_name."'";
						} else {
							$sql = "SELECT * FROM shop";
						}
						$result = mysqli_query($conn, $sql);

						if (mysqli_num_rows($result) > 0) {
							// output data of each row
							
							//echo  '<form method="get" >';// update this form so when you click image you filter the page
							while($row = mysqli_fetch_assoc($result)) {
								$filterArray = array($row['location_name']);//if need to add i need to type in the column in the database i am comparing creating an array which holds the filter boxes in the order they appear on the page
							
								$show = true; // it is used at the end to decide whether or not the destination should be displayed or not
								
								if (isset($_POST['filterSubmit'])){	 //check to see if the user has seleceted anything					
									foreach($_POST['selectFilter'] as $index => $value) { //going through each filter , here it picks all the select filters
										
										if ($value == '') { //check to see if the filter is blank
											continue;
										}
										if ($value != $filterArray[$index]) { // checks to see if the value of the filter box is not equal to the databases value
											$show = false; //if it is not i do not want to show the value
										} 
									}
										
									if ($show == true){	 //if true i want to show so it continues to the html below
											
										
										
								?><form method="get" action="shopinfo">								
										<div class="col-sm-4 interests-item">								
											<div class="interests-link" data-toggle="modal">
												<div class="caption">
													<div class="caption-content">
													
														<i class="fa fa-search-plus fa-3x" title="<?php echo "{$row['shop_desc']}";?>" value="Details" ></i><br/><?php echo "{$row['shop_name']} in {$row['location_name']}";?><br/>
														<input class="btn btn-primary" type="submit" class='button' value="Details" size="10px">
													</div>
												</div>
												<img src="img/interests/<?php echo "{$row['shop_image']}";?>" class="img-responsive" alt="">
											</div>
										</div>
										<input type="hidden" name="shop_id" value="<?php echo $row['shop_id'] ?>">		
									</form>
						  <?php  
									}
										
								} else {
							?><form method="get" action="shopinfo">								
										<div class="col-sm-4 interests-item">								
											<div class="interests-link" data-toggle="modal">
												<div class="caption">
													<div class="caption-content">
													
														<i class="fa fa-search-plus fa-3x" title="<?php echo "{$row['shop_desc']}";?>" value="Details" ></i><br/><?php echo "{$row['shop_name']} in {$row['location_name']}";?><br/>
														<input class="btn btn-primary" type="submit" class='button' value="Details" size="10px">
													</div>
												</div>
												<img src="img/interests/<?php echo "{$row['shop_image']}";?>" class="img-responsive" alt="">
											</div>
										</div>
										<input type="hidden" name="shop_id" value="<?php echo $row['shop_id'] ?>">		
									</form>
						<?php
									
								}
							}
						} else {
							echo "0 results";
						}

						mysqli_close($conn);?>

						
												</form>
			

					

					

					

					

				

            </div>

        </div>

											



    </section>


    
  <?php include "core/footer.php";?>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-top page-scroll visible-xs visible-sm">
        <a class="btn btn-primary" href="#page-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </div>


    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/freelancer.js"></script>

</body>

</html>
