	<?php
// Stesting if the username exists if not a registration can be created
	
				if(isset($_POST['submit']))  
				{
					$username = $_POST['username'];
					$firstpass = $_POST['password'];
					$passwordcheck = $_POST['passwordcheck'];
					$name = $_POST['name'];
					$email = $_POST['email'];
					$phone = $_POST['phone'];
					$hp = $_POST['hp'];
					if ($firstpass == $passwordcheck && empty($hp))
					 {
					$sql = "SELECT * FROM user WHERE username = '".$username."'";
					$result = mysqli_query($conn, $sql);
					
					if (mysqli_num_rows($result) > 0) {
						$sql = "SELECT password FROM user WHERE username = '".$username."'";
						$result = mysqli_query($conn, $sql);
						while($row = mysqli_fetch_assoc($result)) {
							
							
							
							echo' <div class="alert alert-danger">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Sorry!</strong> Username is taken!
					</div>';
						}
					}
					
						else                
						{
							$pass= password_hash($_POST['password'], PASSWORD_BCRYPT); //http://php.net/manual/en/function.password-hash.php Using the PASSWORD_BCRYPT as the algorithm, will result in the password parameter being truncated to a maximum length of 72 characters. Need to limit password length
						if (!$pass){ die ("Something went wrong!");
						}
						else{
						$sql = "INSERT INTO user (Username,Name,Password,Email,Phone) VALUES ('$username','$name','$pass','$email','$phone')"; 
						mysqli_query($conn,$sql);}
						mysqli_close($conn);
						echo '<div class="alert alert-success">
							  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							  <strong>Success!</strong> You have registered!
							</div>';
						header( 'refresh:3;url=index' ) ;
						} 
					}
					else{ echo 
					//http://www.w3schools.com/bootstrap/bootstrap_alerts.asp
					' <div class="alert alert-danger">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<strong>Caution!</strong>  The passwords do not match!
					</div>';	
						}
				}
				else                
				{
					echo '';
				} 
				

?>		