<?php
$servername = "localhost";
$username = "didi";
$password = "980500";
$dbname = "bghotels";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM interest";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo  " - Name: " . $row["interest_name"]. " " . $row["interest_description"]. "<br>";
    }
} else {
    echo "0 results";
}

mysqli_close($conn);
?> 

