<?php 



session_start();

include 'php/connect.php';

$location_name = $_GET['location_name'];



?>





<!DOCTYPE html>

<html lang="en">



<head>



    <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">

    <meta name="author" content="">



    <title>Bulgarian Hotels</title>



    <!-- Bootstrap Core CSS - Uses Bootswatch Flatly Theme: http://bootswatch.com/flatly/ -->

    <link href="css/bootstrap.min.css" rel="stylesheet">



    <!-- Custom CSS -->

    <link href="css/freelancer.css" rel="stylesheet">



    <!-- Custom Fonts -->

    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">

    <link href="http://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 9]>

        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>

        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

    <![endif]-->
	<link rel="icon" 
      type="image/png" 
      href="http://users.aber.ac.uk/dtg1/cs25010/images/logo.gif"> 


</head>



<body id="page-top" class="index">

	<?php //echo $location_name; ?>

    <!-- Navigation -->

    <nav class="navbar navbar-default navbar-fixed-top">

        <div class="container">

            <!-- Brand and toggle get grouped for better mobile display -->

            <div class="navbar-header page-scroll">

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">

                    <span class="sr-only">Toggle navigation</span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                </button>

                <a class="navbar-brand" href="index">Bulgarian Hotels</a>

            </div>



            <!-- Collect the nav links, forms, and other content for toggling -->

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                <ul class="nav navbar-nav navbar-right">

                    <li class="hidden">

                        <a href="#page-top"></a>

                    </li>

					<li class="page-scroll">

                        <a href="#interests">Hotels</a>

                    </li>
					<li class="page-scroll">

                        <a href="feedback">Reviews</a>

                    </li>

				

					

					

					 <?php

						if(!isset($_SESSION['username']))

						{

							?><li class="page-scroll">

								<a href="login">Log In</a>

							</li>

							 <li class="page-scroll">

								<a href="register">Register</a>

							</li>

							<?php

						}

						else

						{

							?>

							<li class="page-scroll">

								<a href="profile"><?php echo $_SESSION['username'] ?></a>

							</li>

							<li class="page-scroll">

								<a href="logout">Logout</a>

							</li>

							<?php

						}

					?>

                </ul>

            </div>

            <!-- /.navbar-collapse -->

        </div>

        <!-- /.container-fluid -->

    </nav>



    <!-- Header -->

    <header>

        <div class="container" >

            <div class="row">

                <div class="col-lg-12">
				
						<?php 

							$sql = "SELECT * FROM `location` WHERE location_name='$location_name' ";

							$result = mysqli_query($conn, $sql);

							

							if (mysqli_num_rows($result) > 0) {

								// output data of each row

								while($row = mysqli_fetch_assoc($result)) {

								$locdesc= $row['location_description'];
								$locpicc= $row['loc_image_c'];
								
								?><img class="img-responsive" src="img/interests/<?php echo $locpicc;?>" alt=""><?php

								}

							} else {?>
									<img class="img-responsive" src="img/bgh.png" alt=""><?php
								

									}

						?>
				

                    

                    <div class="intro-text">

                        <span class="name"><?php 

							if(isset($_GET['location_name'])) {

								echo $_GET['location_name'];

							} else {

								echo "Hotel";

							};

						?></span>

                        <hr class="star-light">

                        <span class="skills"><?php 

							echo $locdesc;

						?></span>

                    </div>

                </div>

            </div>

        </div>

    </header>



  



   

	

	  <!-- interests Grid Section -->

    <section id="interests">

        <div class="container">

            <div class="row">

                <div class="col-lg-12 text-center">

                    <h2>Hotels and Resorts</h2>

                    <hr class="star-primary">

                </div>

            </div>

			<div class="row" align="center">  

<a href="#filtercontainer" class="btn btn-primary" data-toggle="collapse">Filter Options</a>	

 <div   id="filtercontainer" class="collapse" >   <br>		

			<?php

					

					echo "<form name='filter' method='get' action='hotel.php'>";	

				$sql = "SELECT DISTINCT hotel_type FROM hotel"; // this changes in different filters depending what i want 

				$result = mysqli_query($conn, $sql);

				?>  <div class="col-lg-3 text-center"> <?php 



				echo "<label for='hotel_type'>Accommodation type: </label>";

					echo "<select class='form-control input-sm' name='selectFilter[]'>";// i need to give any filter this name copy from here

					echo   "<option value=''></option>";

					while ($row = mysqli_fetch_assoc($result)) {

						echo "<option value='" . $row['hotel_type'] . "'>" . $row['hotel_type'] . "</option>";

					}

					echo "</select>"; //to here to create new filter

					

					?> </div> <div class="col-lg-2 text-center"> <?php

				

					$sql = "SELECT DISTINCT stars FROM hotel";

					$result = mysqli_query($conn, $sql);

					echo "<label for='stars'>Stars: </label>";

					echo "<select class='form-control input-sm' name='selectFilter[]'>"; // i need to give any filter this name 

					echo "<option value=''></option>";

					while ($row = mysqli_fetch_assoc($result)) {

						echo "<option value='" . $row['stars'] . "'>" . $row['stars'] . "</option>";

					}

					echo "</select>";

					

					?> </div> <div class="col-lg-2 text-center"> <?php

					

					$sql = "SELECT DISTINCT price_range FROM hotel";

					$result = mysqli_query($conn, $sql);

					echo "<label for='price_range'>Price Range: </label>";

					echo "<select class='form-control input-sm' name='selectFilter[]'>"; // i need to give any filter this name 

					echo "<option value=''></option>";

					while ($row = mysqli_fetch_assoc($result)) {

						echo "<option value='" . $row['price_range'] . "'>" . $row['price_range'] . "</option>";

					}

					echo "</select>";

					

					?> </div> <div class="col-lg-2 text-center"> <?php

					

					$sql = "SELECT DISTINCT location_name FROM hotel";

					$result = mysqli_query($conn, $sql);

					echo "<label for='price_range'>Location: </label>";

					echo "<select class='form-control input-sm' name='selectFilter[]'>"; // i need to give any filter this name 

					echo "<option value=''></option>";

					while ($row = mysqli_fetch_assoc($result)) {

						echo "<option value='" . $row['location_name'] . "'>" . $row['location_name'] . "</option>";

					}

					echo "</select>";

					

					?> </div> <br><div class="col-lg-3 text-center"> <?php

					

					echo "<input class='btn btn-primary' name='filterSubmit' type='submit'>";

					?> </div> <?php

				echo"</form> ";

			?>

           </div> </div><br><br>

            <div class="row">

					<?php

					

						if(isset($_GET['location_name'])) {

							$sql = "SELECT * FROM hotel WHERE location_name = '".$location_name."'";

						} else {

							$sql = "SELECT * FROM hotel";

						}

						$result = mysqli_query($conn, $sql);



						if (mysqli_num_rows($result) > 0) {

							// output data of each row

							

							echo  '<form method="get" >';// update this form so when you click image you filter the page

							while($row = mysqli_fetch_assoc($result)) {

								$filterArray = array($row['hotel_type'], $row['stars'],$row['price_range'],$row['location_name']);//if need to add i need to type in the column in the database i am comparing creating an array which holds the filter boxes in the order they appear on the page

							

								$show = true; // it is used at the end to decide whether or not the destination should be displayed or not

								

								if (isset($_GET['filterSubmit'])){	 //check to see if the user has seleceted anything					

									foreach($_GET['selectFilter'] as $index => $value) { //going through each filter , here it picks all the select filters

										

										if ($value == '') { //check to see if the filter is blank

											continue;

										}

										if ($value != $filterArray[$index]) { // checks to see if the value of the filter box is not equal to the databases value

											$show = false;  //if it is not i do not want to show the value

										} 

									}

										

									if ($show){	 //if true i want to show so it continues to the html below

											

										

										

								?>		

												<div class="col-sm-4 interests-item">

												<a href="#<?php echo "{$row['hotel_id']}";?>" class="interests-link" data-toggle="modal">

												

													<div class="caption">

														<div class="caption-content">

															<i class="fa fa-search-plus fa-3x" title="<?php echo "{$row['hotel_description']}";?>" value="Details" ></i>
															<br/><?php echo "{$row['hotel_name']}";?>
															<?php echo "{$row['price']}";?> Pounds per night.

															

														</div>

													</div>

													<img src="img/interests/<?php echo "{$row['hotel_image']}";?>" class="img-responsive" alt="">

												</a>

											</div>

								 

						  <?php  

									}
									

										

								} else {

							?>

												<div class="col-sm-4 interests-item">

												<a href="#<?php echo "{$row['hotel_id']}";?>" class="interests-link" data-toggle="modal">

												

													<div class="caption">

														<div class="caption-content">

															<i class="fa fa-search-plus fa-3x" title="<?php echo "{$row['hotel_description']}";?>" value="Details" ></i><br/>
															<?php echo "{$row['hotel_name']}";?><br/>
															<?php echo "{$row['price']}";?> Pounds per night.

															

														</div>

													</div>

													<img src="img/interests/<?php echo "{$row['hotel_image']}";?>" class="img-responsive" alt="">

												</a>

											</div>

						<?php

									

								}
								

							}

						} else {

							?>
							<div class="alert alert-warning"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<strong>Sorry!</strong> There are no results!
							 </div>
																		  
																		  <?php

						}



						?>



						

												</form>

			

					

					

					

					

				

            </div>

        </div>

											



    </section>



    

   <?php include "core/footer.php";?>



    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->

    <div class="scroll-top page-scroll visible-xs visible-sm">

        <a class="btn btn-primary" href="#page-top">

            <i class="fa fa-chevron-up"></i>

        </a>

    </div>



    <!-- interests Modals -->

  

			<?php

					

						if(isset($_GET['location_name'])) {

							$sql = "SELECT * FROM hotel WHERE location_name = '".$location_name."'";

						} else {

							$sql = "SELECT * FROM hotel";

						}

						$result = mysqli_query($conn, $sql);



						if (mysqli_num_rows($result) > 0) {

							// output data of each row

							

							while($row = mysqli_fetch_assoc($result)) {

							  

								?>	

										

											

											

		<div class="interests-modal modal fade" id="<?php echo "{$row['hotel_id']}";?>" tabindex="-1" role="dialog" aria-hidden="true">

        <div class="modal-content">

            <div class="close-modal" data-dismiss="modal">

                <div class="lr">

                    <div class="rl">

                    </div>

                </div>

            </div>

			            <div class="container">

                <div class="row">

                    <div class="col-lg-8 col-lg-offset-2">

                        <div class="modal-body">

							<form method="get" action="booking">	

								<h2><?php echo "{$row['hotel_name']}";?></h2>

								<hr class="star-primary">

								<img src="img/interests/<?php echo "{$row['hotel_image']}";?>" class="img-responsive img-centered" alt="">

								<p><?php echo "{$row['hotel_description']}";?></p>

								<p><?php echo "Price : {$row['price']} Pounds per night. ";?></p>
								<p><?php echo "Price Range : {$row['price_range']}  ";?></p>

								<p><?php echo "Address : {$row['address']}  ";?></p>

								<p><?php echo "Stars : {$row['stars']}  ";?></p>

								<p><?php echo "Link : <a href='{$row['hotel_link']}' target='_blank'>{$row['hotel_name']} </a> ";?></p>

								

								<ul class="list-inline item-details">

									<li>Feedback:

										<strong><a href="feedback" target='_blank'>View feedback</a>

										</strong>

									</li>

								   

								</ul>

								<input class="btn btn-success btn-lg" type="submit" class='button' value="Book" size="10px">

								<input type="hidden" name="hotel_name" value="<?php echo $row['hotel_name'] ?>">

							</form><br/>
							<form method="get"  action="map" method="get" target="_blank">
							<input class="btn btn-success btn-lg" type="submit" class='button' value="View on map" size="10px">

								<input type="hidden" name="longitude" value="<?php echo $row['longitude'] ?>"> 
								<input type="hidden" name="latitude" value="<?php echo $row['latitude'] ?>">
							</form>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

								 

						  <?php  }

						} else {

							echo "";

						}



						mysqli_close($conn);?>

						

						

						

				  



    <!-- jQuery -->

    <script src="js/jquery.js"></script>



    <!-- Bootstrap Core JavaScript -->

    <script src="js/bootstrap.min.js"></script>



    <!-- Plugin JavaScript -->

    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <script src="js/classie.js"></script>

    <script src="js/cbpAnimatedHeader.js"></script>



    <!-- Contact Form JavaScript -->

    <script src="js/jqBootstrapValidation.js"></script>

    <script src="js/contact_me.js"></script>



    <!-- Custom Theme JavaScript -->

    <script src="js/freelancer.js"></script>



</body>



</html>

