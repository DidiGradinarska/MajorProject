<?php 
session_start();

if(!isset($_SESSION['username']))
	{
							header( 'Location: index' ) ;
							exit();
	}
else
	{
						
$nameuser = $_SESSION['username'];
	include 'php/connect.php';
	
	
	
	
	$sql = "SELECT * FROM user WHERE username='$nameuser'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
		$typeuser = $row["user_type"];
        
    }
} else {
    echo "0 results";
	
	

}


mysqli_close($conn);
	
	
	
if ($typeuser === "user") {
 header( 'Location: profile' ) ;
  
}
else {
	
	 header( 'Location: owner' ) ;
}
	
	
	
	}


?>