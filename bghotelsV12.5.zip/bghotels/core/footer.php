 <!-- Footer -->
    <footer class="text-center">
        <div class="footer-above">
            <div class="container">
                <div class="row">
                      <div class="footer-col col-md-8">
                        <h3>Disclaimer</h3>
                        <p>This is a non-commercial website created for a University Major Project. It doesn't offer any real service. All content, trademarks and logos are properties of their respective owners and are subject to national and international copyright laws. We are not responsible for any issues that may arise from using this site and any similarities to existing logos,trademarks or other intellectual property is purely coincidental.</p>
                    </div>
                    <div class="footer-col col-md-4">
                        <h3>Around the Web</h3>
                        <ul class="list-inline">
                            <li>
                                <a target="_blank" href="https://www.facebook.com/" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i></a>
                            </li>
                            <li>
                                <a  target="_blank" href="https://plus.google.com/" class="btn-social btn-outline"><i class="fa fa-fw fa-google-plus"></i></a>
                            </li>
                            <li>
                                <a target="_blank" href="https://twitter.com/" class="btn-social btn-outline"><i class="fa fa-fw fa-twitter"></i></a>
                            </li>
                           
                        </ul>
                    </div>
                  
                </div>
            </div>
        </div>
        <div class="footer-below">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        Copyright &copy; Bulgarian Hotels 2016
                    </div>
                </div>
            </div>
        </div>
    </footer>