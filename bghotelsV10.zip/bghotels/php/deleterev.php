<?php
session_start();
include 'connect.php';	

$feedback_id = $_POST['feedback_id'];

// sql to delete a record
$sql = "DELETE FROM feedback WHERE feedback_id='$feedback_id'";

if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
	
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}

mysqli_close($conn);
header("Location: ../profile"); 
 
?> 