<?php

session_save_path("../session"); 
session_start();


if(empty($_POST['checkin'])  		||
   empty($_POST['checkout']) 		||
   empty($_POST['hotelname']) 		||
   empty($_POST['email'])	||
   !filter_var($_POST['email'],FILTER_VALIDATE_EMAIL))
   {
	echo "No arguments Provided!";
	return false;
   }
$checkout = $_POST['checkout'];
$email_address = $_POST['email'];
$checkin = $_POST['checkin'];
$hotelname = $_POST['hotelname'];
	
	
	//insert into db here
	
	
// Create the email and send the message

$email_subject = "Website Contact Form:  $name";
$email_body = "You have received a new message from your website contact form.\n\n"."Here are the details:\n\nName: $name\n\nEmail: $email_address\n\nPhone: $phone\n\nMessage:\n$message";
$headers = "From: noreply@bulgarianhotels.com\n"; // This is the email address the generated message will be from. We recommend using something like noreply@yourdomain.com.
$headers .= "Reply-To: $email_address";	
mail($email_address,$email_subject,$email_body,$headers);
return true;	

?>