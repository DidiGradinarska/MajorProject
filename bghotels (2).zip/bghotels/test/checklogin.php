<?php

if (isset($_POST['Submit'])){
 //check if submit button has been pressed the code will only run it it is pressed
$con = mysql_connect("localhost","didi","980500");
if (!$con){
die("Can not connect: " . mysql_error());
}


// username and password sent from form
$myusername=$_POST['myusername'];
$mypassword=$_POST['mypassword'];

// To protect MySQL injection (more detail about MySQL injection)
$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);
$myusername = mysqli_real_escape_string($myusername);
$mypassword = mysqli_real_escape_string($mypassword);

$sql="SELECT * FROM user WHERE username='$myusername' and password='$mypassword'";
$result=mysqli_query($sql,$con);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row

if($count==1){

// Register $myusername, $mypassword and redirect to file "login_success.php"
session_register("myusername");
session_register("mypassword");
header("location:login_success.php");
echo"logged";
}
else { die ("wrong");
//echo "Wrong Username or Password";
}}
?>
