<?php

session_save_path("localhost/bghotels/php/session"); 
session_start();
error_reporting( error_reporting() & ~E_NOTICE )
?>