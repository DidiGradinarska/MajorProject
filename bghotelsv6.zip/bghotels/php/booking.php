<?php

session_save_path("../session"); 
session_start();
include 'connect.php';
$id = doStuff($conn,$_POST);
if($id != null){
	$arr = array('Returned' => $id);
	echo json_encode($arr);
}else{
	throw new Exception("Data Not Saved");
}



function doStuff($conn,$data){
	$id = null;
	if(checkData($data)){
		$checkout = $data['checkout'];
		$email_address = $data['email'];
		$checkin = $data['checkin'];
		$hotelname = $data['hotelname'];
		$rooms = $data['rooms'];
		$currentdate = $data['currentdate'];
		$name = $data['name'];
		if(checkAvailability($conn,$checkin,$checkout,$hotelname)){	
			// Create the email and send the message
			$id= generateId($hotelname,$name,$checkin,$checkout);
			if(insertBooking($conn,$hotelname,$name,$checkin,$checkout,$rooms,$currentdate,$id)){
				sendEmail($email_address,$hotelname,$checkin,$checkout,$id);
			}else{
				$id = null;//failure state
			}
		}
	}
	
	return $id;
}

function checkData($data){
	$good = true;
	if(empty($data['checkin'])  		||
	   empty($data['checkout']) 		||
	   empty($data['hotelname']) 		||
	   empty($data['email'])	||
	   !filter_var($data['email'],FILTER_VALIDATE_EMAIL)){  
		echo "No arguments Provided!";
		$good= false;
	//  To redirect form on a particular page
	}
   return $good;
}


function checkAvailability($conn,$checkin,$checkout,$hotelname){
	$query = "SELECT rooms FROM hotel h WHERE '$hotelname' = h.hotel_name";
	$res = mysqli_query($conn, $query);
	$row = mysqli_fetch_array($res, MYSQLI_ASSOC);
	$totalCapacity = intval($row["rooms"]);

	$begin = new DateTime($checkin);
	$end = new DateTime($checkout);

	$end->modify('+1 day');//check if our checkout day is avialable
	$interval = DateInterval::createFromDateString('1 day');
	$period = new DatePeriod($begin, $interval, $end);
	$available = true;
	foreach ( $period as $dt ){
		$dt = $dt->format('Y-m-d');
		$query= " SELECT number_room,date_in,date_out FROM booking b WHERE b.hotel_name = '$hotelname' AND '$dt' BETWEEN b.date_in AND b.date_out";	
		$res = mysqli_query($conn, $query);
		$totalRooms = 0;
		while ($row = mysqli_fetch_array($res, MYSQLI_ASSOC)) {
			$num = intval($row["number_room"]);
			$totalRooms +=$num;
		}
		$available = ($totalCapacity - $totalRooms)>0;
		if(!$available){
			break;
		}
	}
	return $available;
}

function sendEmail($email_address,$hotelname,$checkin,$checkout,$id){
	$email_subject = "Your reservation confirmation";
	$email_body = "Thank you for using BGHotels to arrange your holiday! We hope you will have an amazing adventure.\n\n".
	"Here are the details of your booking:\n\n
	Booking ID: $id\n\n
	Hotel: $hotelname\n\n
	Email: $email_address\n\n
	Check in date: $checkin\n\n
	Checkout date:$checkout\n\n
	If you have registered with us you will be able to see this information in your profile. Please contact us via our contact form in case of any inquiries.\n\n 
	Disclaimer: This email is generated from a fictional site designed for a University Major Project. If you got this email by accident please do ignore it.\n\n 
	Kind Regards, \n\n 
	BGHotels";
	$headers = "From: noreply@bulgarianhotels.com\n"; // This is the email address the generated message will be from. We recommend using something like noreply@yourdomain.com.
	$headers .= "Reply-To: $email_address";	
	mail($email_address,$email_subject,$email_body,$headers);
}

function insertBooking($conn,$hotelname,$name,$checkin,$checkout,$rooms,$currentdate,$id){
	$sql = "INSERT INTO booking (hotel_name,username,date_in,date_out,number_room,booking_date)
		VALUES ('$hotelname','$name','$checkin','$checkout','$rooms','$currentdate')";
	$success = mysqli_query($conn, $sql);
	mysqli_close($conn);
	return $success;
}
	
function generateId($hotelname,$name,$checkin,$checkout){
	$id = "$hotelname$name$checkin$checkout".microtime();
	//hash ID
	
	return hash('ripemd160',$id);
}




?>